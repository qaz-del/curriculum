import java.util.*;
//@SuppressWarnings("unchecked")
public class tmp
{
	public static void main(String[] args)
	{
		int [][]a=new int[2][];
		a[0]=new int[3];
		a[1]=new int[5];
		System.out.printf("数组a的大小:%d\n",a.length);		//输出:2
		System.out.printf("a[0]的大小:%d\n",a[0].length);	//输出:3
		System.out.printf("a[1]的大小:%d\n",a[1].length);	//输出:5

	}
} 