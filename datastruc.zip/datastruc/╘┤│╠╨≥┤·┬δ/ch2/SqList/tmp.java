//@SuppressWarnings("unchecked")
public class tmp
{
   public static void main(String[] args)
   {
		Integer [] a={1,2,3,4,5};
		SqListClass<Integer> L=new SqListClass<Integer>();
		L.CreateList(a);
		System.out.println("L: "+L.toString());
   }	   
}
 