import java.util.*;
public class tmp
{
	public static void main(String[] args)
	{
		int[] a={1,3,5};
		int k=4;
		System.out.println("k="+k+",结果为 "+Arrays.binarySearch(a,k));
	}
}
