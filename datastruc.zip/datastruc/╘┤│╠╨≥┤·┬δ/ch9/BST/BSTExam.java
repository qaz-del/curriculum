public class BSTExam
{
	public static void main(String[] args)
	{
/*
		int[] a={3,5,6,2,4,3};
		BSTClass bt=new BSTClass();
		for (int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
		System.out.println();
		System.out.println("创建BST");
		bt.CreateBST(a);
		System.out.print("BST: "); bt.DispBST(); System.out.println();
		System.out.print("插入10, BST: "); bt.InsertBST(10); bt.DispBST(); 
		System.out.println();
		System.out.print("插入10, BST: "); bt.InsertBST(10); bt.DispBST();
		System.out.println();
		int k=3;
		System.out.print("查找"+k+",结果"+(bt.SearchBST(k)==null?0:1));		
		System.out.println();
		k=4;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
		k=3;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
		k=1;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
		
		k=2;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
		k=5;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
		k=6;
		System.out.print("删除"+k+", BST: "); bt.DeleteBST(k); bt.DispBST();
		System.out.println();
*/
		int[] a={1,2,3,4,5};
		BSTClass bt=new BSTClass();
		for (int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
		System.out.println();
		System.out.println("创建BST");
		bt.CreateBST(a);


   }	   
}

 